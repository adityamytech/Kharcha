const express = require('express');
const user = require('./routes/user');
const admin = require('./routes/admin');
const mongoose =  require('mongoose');
const bodyParser = require('body-parser')

const app = express();
const port = 3000;

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

mongoose.connect('mongodb://aditya:aditya5@ds129469.mlab.com:29469/kharcha',{useNewUrlParser: true})
.then(()=>console.log('Connected'))
.catch(err=>console.log(err));

app.get('/', (req, res) => res.send('Home Page'));
app.get('/about',(req,res)=>res.send('About Us'));
app.get('/contact',(req,res)=>res.send('Contact Us'));

app.use('/user',user);
app.use('/admin',admin);

app.set('views','./views');
app.set('view engine','ejs');

app.listen(port, () => console.log('Server started'));