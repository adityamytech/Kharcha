const express = require('express');
const router = express.Router();

router.get('/hello',(req,res)=>{
    res.render('user/hello',{title:'User Home'});
});

router.get('/add-expense',(req,res)=>{
    res.render('user/add_expense',{title:'Add Expense'});
});

router.post('/add-expense',(req,res)=>{
    console.log(req.body);
    res.redirect('/user/hello');
})

module.exports = router;