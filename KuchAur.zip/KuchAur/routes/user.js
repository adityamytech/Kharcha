const express = require('express');
const router = express.Router();
const Category= require('../models/category');
const Item = require('../models/item');
const Swal = require('sweetalert2');

router.get('/hello',(req,res)=>{
    res.render('user/hello',{title:'User Home'});
});

router.get('/add-expense',(req,res)=>{
    Category.find().exec((err,listCategory)=>{
        if(err){
            console.log(err);
        }
        console.log(listCategory);
        res.render('user/add_expense',{title:'Add Expense', listCategory : listCategory});
    })
    
});

router.post('/add-expense',(req,res)=>{
    console.log(req.body);
    var item = new Item({
        name : req.body.item,
        price: req.body.price,
        category: req.body.category,
        date: req.body.date
    });
    item.save((err)=>{
        if(err){
            console.log(err);
        }
        console.log('Item Added');
    });
    Swal.fire('Hello world!');
    res.redirect('/user/kharchaas');
});

router.get('/kharchaas',(req,res)=>{
    Item.find()
    .populate('category')
    .exec((err,items)=>{
        if(err){
            console.log(err);
        }
        console.log(items);
        res.render('user/kharchaas',{title:'Kharchaas',items:items});
        Swal.fire('Hello world!');
    })
});

router.get('/analysis',(req,res)=>{
    Item.find()
    .populate('category')
    .exec((err,items)=>{
        if(err){
            console.log(err);
        }
        console.log(items);
        res.render('user/analysis',{title:'Analysis',items:items});
    })
});

module.exports = router;