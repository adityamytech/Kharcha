const express = require('express');
const router = express.Router();

router.get('/hello',(req,res)=>{
    res.render('admin/hello',{title:'Admin Home'});
});

router.get('/add-category',(req,res)=>{
    res.render('admin/add_category',{title:'Add Category'});
});

router.post('/add-category',(req,res)=>{
    console.log(req.body);
    res.redirect('/admin/hello');
});

module.exports = router;