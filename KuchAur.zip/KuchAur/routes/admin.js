const express = require('express');
const router = express.Router();
const Category = require('../models/category');

router.get('/hello',(req,res)=>{
    res.render('admin/hello',{title:'Admin Home'});
});

router.get('/add-category',(req,res)=>{
    res.render('admin/add_category',{title:'Add Category'});
});

router.post('/add-category',(req,res)=>{
    console.log(req.body);
    var category = new Category({
        name: req.body.category
    });
    category.save((err)=>{
        if(err){
            console.log(err);
        }else{
            console.log('Category Created')
        }
    })
    res.redirect('/admin/hello');
});

module.exports = router;